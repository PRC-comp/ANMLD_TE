#!/bin/sh -login

#SBATCH -N 1
#SBATCH --ntasks-per-node 40

#SBATCH --partition=BATCH2

#SBATCH -J TmrABmin
#SBATCH -o output

#SBATCH --mail-user=ayca.a.ersoy@gmail.com
#SBATCH --mail-type=ALL
#SBATCH --no-requeue

source /share/apps/scripts/env_vars.sh

#module load openmpi-x86_64
export MPI_HOME=/share/apps/openmpi-1.4.4/
export PATH=$MPI_HOME/bin:$PATH
export LD_LIBRARY_PATH=$MPI_HOME/lib::${LD_LIBRARY_PATH}


mpirun -np $SLURM_NPROCS $AMBERHOME/exe/sander.MPI -O -i $PWD/min.in -p $PWD/Initial.top -c $PWD/Initial.coord -o $PWD/Initial_min.out -x $PWD/Initial_min.coord -r $PWD/Initial_min.rst </dev/null

mpirun -np $SLURM_NPROCS $AMBERHOME/exe/sander.MPI -O -i $PWD/min.in -p $PWD/Target.top -c $PWD/Target.coord -o $PWD/Target_min.out -x $PWD/Target_min.coord -r $PWD/Target_min.rst </dev/null


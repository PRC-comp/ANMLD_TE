clc
clear all
%%

slow_vectors_anm_cycle1=0;

fid=fopen('step.txt','r+');

tline = fgetl(fid);
tline = fgetl(fid);

while 1
    tline = fgetl(fid);
    
    if ~ischar(tline), break, end
    disp(tline)
    
    
    [f]= textscan(tline,'%d%s%s%s');
    
    cycle_no = f{1};
    coord_4ANM = f{2};
    coord_initial = f{3};
    coord_target = f{4};
    
    [overlapped_modes, overlap_values, degree_collectivity, slow_vectors_anm_current,file1,file2,file3,restricted_modes_new]=anm_gnm_target_overlap(f{1},slow_vectors_anm_cycle1,char(f{2}),char(f{3}),char(f{4}));
    
    overlapped_modes(1)
    overlap_values(1)
    
    mofile = fopen('mode_ov','a');
    
    fprintf(mofile,['Cycle %d %d %6.4f %d %6.4f %d %6.4f %6.4f %6.4f %6.4f ',[repmat('%d ', 1, size(restricted_modes_new, 2)) '\n']], cycle_no, overlapped_modes(1), overlap_values(1), overlapped_modes(2), overlap_values(2), overlapped_modes(3), overlap_values(3), degree_collectivity(1), degree_collectivity(2), degree_collectivity(3),restricted_modes_new);
    fclose(mofile);
    
    ov_col= 1;
    
    
    
    % tleap script
    tleap_command = sprintf('tleap -f tleap_anm_pdbs_cycle%d.in', cycle_no);
    disp(tleap_command);
    status = unix(tleap_command)
    
    % minimization script
    min_command = sprintf('mpirun -np 48 $AMBERHOME/exe/sander.MPI -O -i $PWD/min.in -p $PWD/%s_cycle%d.top -c $PWD/%s_cycle%d.coord -o $PWD/%s_min_cycle%d.out -x $PWD/%s_min_cycle%d.coord -r $PWD/%s_min_cycle%d.rst </dev/null',...
        file1(ov_col,:),cycle_no,file1(ov_col,:),cycle_no,file1(ov_col,:),cycle_no,file1(ov_col,:),cycle_no,file1(ov_col,:),cycle_no);
    
    disp(min_command);
    status = unix(min_command)
    
    % simulation script
    sim_command = sprintf('mpirun -np 48 $AMBERHOME/exe/sander.MPI -O -i $PWD/LD_matlab.in -p $PWD/%s_cycle%d.top -c $PWD/%s_min_cycle%d.rst -ref $PWD/Target_min_algn.rst -o $PWD/%s_cycle%d.out -x $PWD/%s_cycle%d.coord -e $PWD/%s_cycle%d.ener -r $PWD/%s_cycle%d.restart </dev/null',...
        file1(ov_col,:),cycle_no,file1(ov_col,:),cycle_no,file2(ov_col,:),cycle_no,file2(ov_col,:),cycle_no,file2(ov_col,:),cycle_no, file2(ov_col,:),cycle_no);
    
    disp(sim_command);
    status = unix(sim_command)
    
    afile = fopen(sprintf('ptraj_align_cycle%d.in',cycle_no),'w');
    fprintf(afile,'trajin %s_cycle%d.restart \nreference Target_min_algn.rst \nrms reference :1-1154@CA out rms_cycle%d.dat\ntrajout %s_cycle%d_algn.restart restart\n',...
        file2(ov_col,:),cycle_no,cycle_no,file2(ov_col,:),cycle_no);
    fclose(afile);
    
    % alignment
    align_command = sprintf('ptraj %s_cycle%d.top ptraj_align_cycle%d.in', file1(ov_col,:),cycle_no, cycle_no);
    disp(align_command);
    status = unix(align_command)
    
    % pdb creation command
    pdb_command_CA = sprintf('ambmask -p %s_cycle%d.top -c %s_cycle%d_algn.restart.1 -prnlev 1 -out pdb -find @CA>%s_cycle%d_C.pdb',file1(ov_col,:),cycle_no,file2(ov_col,:),cycle_no, file2(ov_col,:),cycle_no);
    
    pdb_command_all_atom = sprintf('ambmask -p %s_cycle%d.top -c %s_cycle%d_algn.restart.1 -prnlev 1 -out pdb >%s_cycle%d.pdb',file1(ov_col,:),cycle_no,file2(ov_col,:),cycle_no, file2(ov_col,:),cycle_no);
    
    disp(pdb_command_CA);
    status = unix(pdb_command_CA);
    
    disp(pdb_command_all_atom);
    status = unix(pdb_command_all_atom);
    
    if cycle_no == 1
        slow_vectors_anm_cycle1=slow_vectors_anm_current;
    end
    
    if cycle_no+1 == 202, break, end
    
    offset1 = ftell(fid)
    fprintf(fid,'%d %s_cycle%d_C.pdb %s_cycle%d.pdb %s \t \n',cycle_no+1, file2(ov_col,:),cycle_no, file2(ov_col,:),cycle_no, file3);
    offset2 = ftell(fid)
    
    fseek(fid, -1*(offset2-offset1), 'cof')
    
    ftell(fid)
    
    
end

fclose(fid);


quit

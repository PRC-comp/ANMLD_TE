#!/bin/bash
#SBATCH -N 1
#SBATCH --ntasks-per-node 40

#SBATCH --partition=BATCH3

#SBATCH -J TmrAB_run13
#SBATCH -o output

#SBATCH --mail-user=ayca.a.ersoy@gmail.com
#SBATCH --mail-type=ALL
#SBATCH --no-requeue

source /share/apps/scripts/env_vars.sh

#module load openmpi-x86_64
export MPI_HOME=/share/apps/openmpi-1.4.4/
export PATH=$MPI_HOME/bin:$PATH
export LD_LIBRARY_PATH=$MPI_HOME/lib::${LD_LIBRARY_PATH}


#your command should be in here
matlab -nojvm -nodisplay -r matlab_newmethod > matlab.log


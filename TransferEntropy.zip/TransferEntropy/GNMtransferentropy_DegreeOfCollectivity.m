% clc;clear all;

%% Reading coordinates from PDB
fname1='';
name='';
domain=[];  
lig1 = [];
lig2 = [];
lig3=[];
lig4=[];

[d1, d2, d3, d4, d5,d6, x_1, y_1, z_1, d7, d8, d9]=textread(fname1,'%s%f%s%s%s%f%f%f%f%f%f%s','headerlines',1); % 4AKEC.pdb

A=strcmp(d3,'CA'); %To grep CA atoms only.

x_1=x_1(A);
y_1=y_1(A);
z_1=z_1(A);

x=[x_1']; 
y=[y_1'];
z=[z_1'];

real_index=d6(A);

%  general
resnum=size(x,2); 
frame=size(x,1);

%% GNM Parameters
rcut_gnm=10.0;
ga=1;
t0=6;

%% preallocate arrays
A=zeros(resnum,resnum);
U=zeros(resnum,resnum);
S=zeros(resnum,resnum);
V=zeros(resnum,resnum);
w=zeros(resnum,frame);
%% GNM Calculation
for j=1:resnum
    for k=1:resnum
         distx = x(1,j)-x(1,k);   
         disty = y(1,j)-y(1,k);   
         distz = z(1,j)-z(1,k);
         
         r=sqrt(distx^2+disty^2+distz^2);
        % Kirchhoff
        if (r <= rcut_gnm && j~=k && r > 0.0001)
            A(j,k)=-1;
        else
            A(j,k)=0;                                
        end
    end
end

% detailed balance for connectivity matrix
diagonal=sum(A(:,:));
for j=1:resnum
    for i=1:resnum
        if i == j
            A(i,j)=-1*diagonal(i); % Kirchhoff
        end
    end
end

[U(:,:),S(:,:),V(:,:)]=svd(A(:,:)); %singular value decomposition (V=mode vector)
winit=diag(S(:,:)); % eig(A)=winit !!! eigenvalues. 
S1=pinv(S); % returns the Moore-Penrose Pseudoinverse of matrix S.
w=diag(S1(:,:)); % w=1/winit. Eigenvector^(-1)

%% GNM Entropy Transfer

indx=0;
tau=opttau(1,1)*4; %from optimumtau.m code

for i=1:resnum
for j=1:resnum

    if i==j
        Tij(i,j)=0;
    else
sum11=0;sum12=0;sum21=0;sum23=0;sum27=0;sum25=0;

% Selects desired mode range
m1=1;
m2=10;

for k=resnum-m2:resnum-m1 
 
   sum11=sum11+w(k)*V(j,k)*V(j,k); 
   sum12=sum12+(w(k)*V(j,k)*V(j,k))*exp(-(winit(k)*tau)/t0);
   sum21=sum21+w(k)*V(i,k)*V(i,k);
   sum23=sum23+w(k)*V(i,k)*V(j,k);
   sum25=sum25+(w(k)*V(i,k)*V(j,k))*exp(-(winit(k)*tau)/t0);
   
end


sum22=sum11;
sum24=sum12;
sum26=sum25;
sum27=sum23;
sum28=sum11;
sum29=sum12;
sum210=sum21;
sum31=sum11;
sum41=sum21;
sum42=sum11;
sum43=sum23;

a=sum11^2-sum12^2;
b=(sum21*sum22*sum22)+(2*sum23*sum24*sum25)-(sum26^2+sum27^2)*sum28-sum29^2*sum210;
c=sum31;
d=sum41*sum42-sum43*sum43;

if abs(a)<10^-5 && a<0
    a=abs(a);
end

if abs(b)<10^-5 && b<0
    b=abs(b);
end

if abs(c)<10^-5 && c<0
    c=abs(c);
end

if abs(d)<10^-5 && d<0
    d=abs(c);
end

comp1=0.5*reallog(a);
comp2=0.5*reallog(b);
comp3=0.5*reallog(c);
comp4=0.5*reallog(d);

Tij(i,j)=comp1-comp2-comp3+comp4;
    end
%Tij(indx)=comp1-comp2-comp3+comp4;
%sum12tau(indx)=sum12;
end
end

for i=1:resnum
    for j=1:resnum
        net(i,j)=Tij(i,j)-Tij(j,i); 
    end
end
netSum = sum(net,2);


%Collectivity calculations

net(isnan(net))=0.000000001;

netp=net;
for i=1:resnum
    for j=1:resnum
        if net(i,j)<=0
            netp(i,j)=0.000000001; %takes only positive col. values
        end
    end
end
    
countt=0;
count=zeros;
for i=1:resnum
    for j=1:resnum
        if net(i,j)>0
           count(i,1)=countt+1; %Count(i,1) gives how many positive TE values the residue i has
        end
    end
end

Sq=netp.^2;
summ1=sum(Sq,2);  

alfa1=zeros;
insidesum1=zeros;
summation1=zeros;
col1=zeros; % collectivity, denoted as K in the equation.
for i=1:resnum
    alfa1(i,1)=1/summ1(i,1);  
    for j=1:resnum
        insidesum1(i,j)=alfa1(i,1)*(netp(i,j)^2)*log(alfa1(i,1)*netp(i,j)^2);
    end
    insidesum1(i,i)=0; % to eliminate NaN terms. 
    summation1(i,1)=sum(insidesum1(i,:)); 
    col1(i,1)=exp(-1*summation1(i,1))*(1/resnum); % N=resnum
end

% average netp values for each residue:
summ_netp=zeros;
netp_avg=zeros;
for i=1:resnum
    sum_netp=0;
    for j=1:resnum
    summ_netp(i,1)=sum_netp+netp(i,j);
    sum_netp=summ_netp(i,1);
    end
    netp_avg(i,1)=summ_netp(i,1)/count(i,1); % net TE values for residue i. 
end

Sq=netp.^2;
summ2=sum(Sq,2);  
alfa2=zeros;
insidesum2=zeros;
summation2=zeros;
col2=zeros; % collectivity, denoted as k in the equation.
for i=1:resnum
    alfa2(i,1)=1/summ2(i,1);  
    for j=1:resnum
        insidesum2(i,j)=alfa2(i,1)*(netp(i,j)^2)*log(alfa2(i,1)*netp(i,j)^2);
    end
    insidesum2(i,i)=0; % to eliminate NaN terms. 
    summation2(i,1)=sum(insidesum2(i,:)); 
    col2(i,1)=netp_avg(i,1)*(exp(-1*summation2(i,1))*(1/resnum)); %N=resnum
end

% Collectivity Calculations chain-by-chain
domainLimits = [1 domain resnum];
col_domain=zeros;

for k=1:(size(domainLimits,2)-1)
    for m=1:(size(domainLimits,2)-1)
        col3=zeros;
        insidesum2=zeros;
        summation2=zeros;
        alfa2=zeros;
        
        for i=domainLimits(k):domainLimits(k+1)
            alfa2(i,1)=1/summ2(i,1);
            for j=domainLimits(m):domainLimits(m+1)
                insidesum2(i,j)=alfa2(i,1)*(netp(i,j)^2)*log(alfa2(i,1)*netp(i,j)^2);
            end
            insidesum2(i,i)=0; % to eliminate NaN terms.
            summation2(i,1)=sum(insidesum2(i,:));
            col3(i,1)=netp_avg(i,1)*(exp(-1*summation2(i,1))*(1/resnum)); %N=resnum
            col3(isnan(col3))=0;
            col_domain(size(domainLimits,2)-k,m)=sum(col3)/(domainLimits(k+1)-domainLimits(k));
        end
    end
end


%% PLOTTING

f1=figure
f1=imagesc(1:resnum,1:resnum,net); 
set(gca,'YDir','normal');
set(gca,'FontSize',14, 'FontWeight', 'normal');

title(['GNM Entropy Tranfer Map for ', name,' (' , num2str(m1), '-', num2str(m2), ' Modes Tau:',num2str(tau),')'],'Fontsize',14);

xlabel('Residue number (Affected)','FontSize',16);
ylabel('Residue number (Effector)','FontSize',16);
axis square;

colorbar
caxis([-0.01 0.01]);
colormap(jet)
%Additional markers on 1st plot
hold on
figure(1)
for i=domain
    line([i i],[0 size(col1,1)], 'LineWidth',4,'Color','w')
    line([0 size(col1,1)],[i i], 'LineWidth',4,'Color','w')
end
zero_y=ones(1,size(lig2,2));
scatter(lig2,zero_y,100,[.5,.5,.5],'^','filled')
scatter(zero_y,lig2,100,[.5,.5,.5],'>','filled')
zero_y=ones(1,size(lig1,2));
scatter(lig1,zero_y,100,[.8,.8,.8],'^','filled')
scatter(zero_y,lig1,100,[.8,.8,.8],'>','filled')
zero_y=ones(1,size(lig3,2));
scatter(lig3,zero_y,100,[.5,.5,.5],'^','filled')
scatter(zero_y,lig3,100,[.5,.5,.5],'>','filled')
zero_y=ones(1,size(lig4,2));
scatter(lig4,zero_y,100,[.8,.8,.8],'^','filled')
scatter(zero_y,lig4,100,[.8,.8,.8],'>','filled')


f2=figure
f2=subplot(3,1,1);
ligandLines(lig1,lig2,lig3,lig4,max(col1)*1.2,0)
hold on
f2=plot(1:resnum,col1)
title([name,' - Degree of Collectivity Plot (' , num2str(m1), '-', num2str(m2), ' Modes Tau:',num2str(tau),')'], 'Fontsize',14);
xlim([0 resnum])
xlabel('Residue Number','Fontsize',14);
ylabel('Degree of Collectivity','Fontsize',14);
hold off
f2=subplot(3,1,2);
ligandLines(lig1,lig2,lig3,lig4,max(col2)*1.2,0)
hold on
f2=plot(1:resnum,col2);
title(['TE x Collectivity Plot (' , num2str(m1), '-', num2str(m2), ' Modes Tau:',num2str(tau),')'], 'Fontsize',14);
xlim([0 resnum])
xlabel('Residue Number','Fontsize',14);
ylabel('TE x Collectivity','Fontsize',14);
f2=subplot(3,1,3)
ligandLines(lig1,lig2,lig3,lig4,quantile(netSum, 0.99)*1.2,quantile(netSum, 0.01)*1.2)
plot(1:resnum,netSum,'LineWidth',1)
ylabel('Entropy out','FontSize',14);
xlabel('Residue Number','FontSize',14')
title(['Cumulative Transfer Entropy (' , num2str(m1), '-', num2str(m2), ' Modes Tau:',num2str(tau),')'], 'Fontsize',14);
%set(gca,'FontSize',14, 'FontWeight', 'normal');
xlim([1 resnum])

limit=quantile(netSum, 0.9);
[pks2,locs2]=findpeaks(netSum,'MinPeakHeight',limit);
Peaks_Locs2=[locs2,pks2]; %creates a matrix with collectivity peaks (>0.45) and their x indeces (not real indeces).
Real_peaks2=real_index(locs2);
SUM_PEAKS=[Peaks_Locs2,Real_peaks2]; % [X locations, collectivity, real indeces]






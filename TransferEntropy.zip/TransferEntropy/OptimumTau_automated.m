%clear all; clc;
%% Reading coordinates from PDB
fname1=''; % PDB file
[d1, d2, d3, d4, d5,d6, x_1, y_1, z_1, d7, d8, d9]=textread(fname1,'%s%f%s%s%s%f%f%f%f%f%f%s','headerlines',1); % 4AKEC.pdb

A=strcmp(d3,'CA'); %To grep CA atoms only.

x_1=x_1(A);
y_1=y_1(A);
z_1=z_1(A);

x=[x_1']; 
y=[y_1'];
z=[z_1'];


%  general
resnum=size(x,2); 
frame=size(x,1);

%% GNM Parameters
rcut_gnm=10.0; %A
ga=1;
t0=6;

%% preallocate arrays
A=zeros(resnum,resnum);
U=zeros(resnum,resnum);
S=zeros(resnum,resnum);
V=zeros(resnum,resnum);
w=zeros(resnum,frame);

%% GNM Calculation
for j=1:resnum
    for k=1:resnum
         distx = x(1,j)-x(1,k);   
         disty = y(1,j)-y(1,k);   
         distz = z(1,j)-z(1,k);
         
         r=sqrt(distx^2+disty^2+distz^2);
        % Kirchhoff
        if (r <= rcut_gnm && j~=k && r > 0.0001)
            A(j,k)=-1;
        else
            A(j,k)=0;                                
        end
    end
end

% detailed balance for connectivity matrix
diagonal=sum(A(:,:));
for j=1:resnum
    for i=1:resnum
        if i == j
            A(i,j)=-1*diagonal(i); % Kirchhoff
        end
    end
end
    
[U(:,:),S(:,:),V(:,:)]=svd(A(:,:)); %singular value decomposition
winit=diag(S(:,:));  %eigenvalues        
S1=pinv(S);
w=diag(S1(:,:));  

%% GNM Entropy Transfer
% Ti>j(tau)
i=100; %i=resnum1; %100
j=24; %j=resnum2; %25

indx=0;
for tau=0.01:0.01:200
    indx=indx+1;

sum11=0;sum12=0;sum21=0;sum23=0;sum27=0;sum25=0;


for k= resnum-10:resnum-2

    sum11=sum11+w(k)*V(j,k)*V(j,k);
    sum12=sum12+(w(k)*V(j,k)*V(j,k))*exp(-(winit(k)*tau)/t0);
    sum21=sum21+w(k)*V(i,k)*V(i,k);
    sum23=sum23+w(k)*V(i,k)*V(j,k);
    sum25=sum25+(w(k)*V(i,k)*V(j,k))*exp(-(winit(k)*tau)/t0);

end


sum22=sum11;
sum24=sum12;
sum26=sum25;
sum27=sum23;
sum28=sum11;
sum29=sum12;
sum210=sum21;
sum31=sum11;
sum41=sum21;
sum42=sum11;
sum43=sum23;

a=sum11^2-sum12^2;
b=(sum21*sum22*sum22)+(2*sum23*sum24*sum25)-(sum26^2+sum27^2)*sum28-sum29^2*sum210;
c=sum31;
d=sum41*sum42-sum43*sum43;

if abs(a)<10^-5 && a<0
    a=abs(a);
end

if abs(b)<10^-5 && b<0
    b=abs(b);
end

if abs(c)<10^-5 && c<0
    c=abs(c);
end

if abs(d)<10^-5 && d<0
    d=abs(c);
end

comp1=0.5*reallog(a);
comp2=0.5*reallog(b);
comp3=0.5*reallog(c);
comp4=0.5*reallog(d);


Tij(indx)=comp1-comp2-comp3+comp4;
sum12tau(indx)=sum12;
end



% Plotting tau performance
plot(0.01:0.01:200,Tij)
xlabel('tau','FontSize',14);
ylabel('Tij','FontSize',14);

[pks, locs]=findpeaks(Tij,0.01:0.01:200);
opttau=locs;
opttau(1,1)